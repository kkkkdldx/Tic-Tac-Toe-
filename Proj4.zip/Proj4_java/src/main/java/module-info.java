module com.example.proj4_java {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.proj4_java to javafx.fxml;
    exports com.example.proj4_java;
}